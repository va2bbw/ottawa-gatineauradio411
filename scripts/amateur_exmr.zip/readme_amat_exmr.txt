Each record has the following data, separated by ";"

First Names
Surname
Address
City
Province
Phone Number 1
Phone Number 2
Email Address
Expiry Date (YYYY-MM-DD)
Postal Code
