Each record has the following data, separated by ";"

Callsign
Given Names
Surname
Street Address
City
Province
Postal/ZIP Code
BASIC Qualification (A)
5WPM Qualification (B)
12WPM Qualification (C)
ADVANCED Qualification (D)
Basic with Honours (E)
Club Name (field 1)
Club Name (field 2)
Club Address
Club City
Club Province
Club Postal/ZIP Code
